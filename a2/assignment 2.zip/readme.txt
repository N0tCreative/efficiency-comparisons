Name: Jerad Arnold
ID: 1008362
Assignment: assignment 2

Description:
	each c file has its own main.
	to compile all just type make
	to execute either type ./p** ./directory/to/file
	or ./p**
	if no directory is included it defaults to ./data_1.txt for ./p1* and ./data_2.txt for ./p2*
	